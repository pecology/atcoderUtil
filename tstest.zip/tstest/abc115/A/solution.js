"use strict";
exports.__esModule = true;
var fs = require("fs");
var STD_INPUT_FILEDESCRIPTOR = 0;
var main = function () {
    var stdInput = fs.readFileSync(STD_INPUT_FILEDESCRIPTOR, { encoding: "utf8" });
    // Write your code!!
    console.log("answer!!");
    // process.stdout.write() does not insert a line break at the end
    // If you want, please use console.log()
};
main();
