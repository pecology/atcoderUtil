import * as fs from "fs"

const STD_INPUT_FILEDESCRIPTOR = 0;

const main = () => {
    const stdInput = fs.readFileSync(STD_INPUT_FILEDESCRIPTOR, {encoding: "utf8"});
    
    // Write your code!!

    console.log("abc119!!");
    // process.stdout.write() does not insert a line break at the end
    // If you want, please use console.log()
};

main();
