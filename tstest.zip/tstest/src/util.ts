import {Readable} from "stream"
import * as https from "https"
import { readFileSync } from "fs";

export interface IO{
    input: string,
    output: string
};

export function readAll(readableStream: Readable):Promise<string> {
    return new Promise((resolve, reject) => {
        if(!readableStream.readable) {
            reject(new Error(`stream ${readableStream} is not readable`));
        }
        
        readableStream.setEncoding("utf8");

        let str = "";
        readableStream.on("data", (chunk) => {
            str += chunk;
        });
        readableStream.on("end", () => {
            resolve(str);
        });
        readableStream.on("error", (err) => {
            reject(err);
        });
    });
};

export function getHtml(url: string) {
    return new Promise<string>((resolve, reject) => {
        const request = https.get(url, async (response) => {
            if(!response.statusCode) {
                reject(new Error("statusCode is undifined."));
            }
            else if(response.statusCode < 200 || response.statusCode > 299){
                reject(new Error(`statuCode: ${response.statusCode}.`));
            }

            const html = await readAll(response);
            resolve(html);
        });
        request.on('error', (err) => reject(err));
    });
};