export enum Color{
    NONE = "0",
    RED = "31",
    GREEN = "32"
}