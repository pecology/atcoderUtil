// let stdInput = "";
// process.stdin.on('data', (chunk) =>{
//     stdInput += chunk;
// });

// process.stdin.on('end', () =>{
//     main(stdInput);
// });

// const main = (stdInput:string): void => {
//     // Write your code!!
//     const numOfMochi = parseInt(stdInput.split('\n')[0]);
//     const mochiList = stdInput.split('\n').splice(1, numOfMochi).map(i => parseInt(i));
//     const mochiSet = new Set(mochiList);

//     console.log(mochiSet.size);
    

//     // process.stdout.write() does not insert a line break at the end
//     // If you want, please use console.log()
// }