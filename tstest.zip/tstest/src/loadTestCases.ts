import { readFileSync, readdirSync } from "fs";
import * as path from "path";
import TestCase from "./testCase";

export default function loadTestCases(testCaseDirectory: string){
    const directoryNames = readdirSync(testCaseDirectory);

    const samples = new Array<TestCase>();
    for(const directoryName of directoryNames) {
        const directoryPath = path.join(testCaseDirectory, directoryName);
        const inputFilePath = path.join(directoryPath, "input.txt");
        const outputFilePath = path.join(directoryPath, "output.txt");
        samples.push({
            name: directoryName,
            input: readFileSync(inputFilePath, {encoding: "utf8"}),
            output: readFileSync(outputFilePath, {encoding: "utf8"})
        });
    }

    return samples;
};