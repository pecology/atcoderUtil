import * as path from "path"
import * as childProcess from "child_process"

export default (tsSourcePath: string): string => {
    //TODO: error handling
    //TODO: promisefy
    const tscPath = path.resolve(process.argv[1], "../", "../", "node_modules", ".bin", "tsc");
    childProcess.execSync(`${tscPath} ${tsSourcePath}`);

    const jsSourcePath = tsSourcePath.split('.')[0] + ".js";
    return jsSourcePath;
}