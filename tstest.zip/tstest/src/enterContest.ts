#!/usr/bin/env node

import * as util from "./util"
import * as cheerio from "cheerio"
import * as fs from "fs"
import * as path from "path"
import fetchTestCase from "./fetchTestCase"
import * as url from "url"

interface TaskInfo {
    taskCode: string,
    url: string
}

export default async function enterContest(contestCode: string){
    const taskUrl = `https://atcoder.jp/contests/${contestCode}/tasks`;

    const tasksPageHtml = await util.getHtml(taskUrl);
    
    const taskInfoList = extractTaskInfoList(tasksPageHtml);

    const contestPath = path.join(process.cwd(), contestCode);
    fs.mkdirSync(contestPath);
    taskInfoList.forEach(async (taskInfo) => {
        const taskDirPath = path.join(contestPath, taskInfo.taskCode);
        fs.mkdirSync(taskDirPath);

        const solutionTemplatePath = path.resolve(process.argv[1], "../", "../", "src", "solutionTemplate.ts");
        fs.copyFileSync(solutionTemplatePath, path.join(taskDirPath, "solution.ts"));

        const testDirPath = path.join(taskDirPath, "test");
        fs.mkdirSync(testDirPath);

        const absoluteUrl = new url.URL(taskInfo.url, "https://atcoder.jp/");
        const samples = await fetchTestCase(absoluteUrl.toString());
        samples.forEach((sample, i) => {
            const sampleIndex = i + 1;
            const sampleDirPath = path.join(testDirPath, sampleIndex.toString());
            fs.mkdirSync(sampleDirPath);

            const inputFilePath = path.join(sampleDirPath, "input.txt");
            fs.writeFileSync(inputFilePath, sample.input);
            const outputFilePath = path.join(sampleDirPath, "output.txt");
            fs.writeFileSync(outputFilePath, sample.output);
        });
    });
}

const extractTaskInfoList = (tasksPageHtml: string): TaskInfo[] => {
    const $ = cheerio.load(tasksPageHtml);
    const taskInfoAnchorElements = $("tbody > tr > td:first-child > a");
    return taskInfoAnchorElements.toArray().map((e) => {
        return {
            taskCode: e.firstChild.data ? e.firstChild.data : "",
            url: e.attribs["href"]
        }
    });
}
console.log(process.argv[2])
enterContest(process.argv[2]);