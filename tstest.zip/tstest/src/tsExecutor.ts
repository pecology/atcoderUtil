import compileTs from "./compileTs";
import execSolution from "./execSolution";
import CodeExecutor from "./codeExecutor";


export default class TsExecutor implements CodeExecutor{
    private compiledJsSrcPath: string;

    constructor(tsSrcPath: string){
        this.compiledJsSrcPath = compileTs(tsSrcPath);
    }

    /**
     * execute
     */
    public execute(standartInput?: string, ...commandLineArgs: string[]) {
        return execSolution(this.compiledJsSrcPath, standartInput, ...commandLineArgs);
    }
}