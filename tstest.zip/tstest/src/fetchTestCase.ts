import * as cheerio from "cheerio"
import {IO, getHtml} from "./util"

export default async function fetchTestCase(problemUrl: string){
    const problemHtml = await getHtml(problemUrl);    
    const $ = cheerio.load(problemHtml);

    let testCases = new Array<IO>();
    let testCaseIndex = 1;
    while (1) {
        const sampleIoElement = $(`.part h3:contains(${testCaseIndex}) + pre`);
        if(sampleIoElement.length === 0){
            break;
        }
        const sampleInput = sampleIoElement.eq(0).text();
        const sampleOutput = sampleIoElement.eq(1).text();
        testCases.push({input: sampleInput, output: sampleOutput});

        testCaseIndex++;
    }

    return testCases;
};