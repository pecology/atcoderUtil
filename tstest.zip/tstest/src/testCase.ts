export default interface TestCase {
    name: string,
    input: string,
    output: string
}