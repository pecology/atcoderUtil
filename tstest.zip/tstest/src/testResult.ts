export default interface TestResult {
    testName: string,
    result: string,
    success: boolean
}