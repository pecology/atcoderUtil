import loadTestCases from "./loadTestCases"
import * as path from "path"
import {default as Logger} from "./logger"
import { Color } from "./color";
import TsExecutor from "./tsExecutor";
import Output from "./output"
import CodeExecutor from "./codeExecutor";
import TestResult from "./testResult";
import TestCase from "./testCase";

interface ILogger{
    log: (content: string, color?: Color) => void
}

const test = async (solution: CodeExecutor, testCase: TestCase): Promise<TestResult> => {
    console.log(`TestCase:${testCase.name}`);
    let output: Output;
    try{
        output = await solution.execute(testCase.input)
    }
    catch(e) {
        return Promise.reject(e);
    };

    if(output.exitCode === 0) {
        let result = "";
        result +=
            `----input--------------
            ${testCase.input}
            ----expected-----------
            ${testCase.output}
            ----actual-------------
            ${output.standardOutput}
            -----------------------\n`;

        const success = testCase.output === output.standardOutput;
            
        if(success) {
            result += "OK";
        }
        else {
            result += "NG";
        }
        result += "\n";

        return {
            testName: "",
            result: result,
            success: success
        };
    }
    else {
        let result ="";
        result += `exit code is not zero.\n`;
        result += `exit code: ${output.exitCode}\n`;
        result += `standard error:\n${output.standardError}\n`;

        return {
            testName: "",
            result: result,
            success: false
        };
    }
}

(async () => {
    //TODO: validate args
    const contestCode = process.argv[2];
    const taskCode = process.argv[3];

    const solutionPath = path.join("./", contestCode, taskCode, "solution.ts");
    const solutionExecutor: CodeExecutor = new TsExecutor(solutionPath);

    const testCaseDirectory = path.join("./", contestCode, taskCode, "test");
    const testCases = loadTestCases(testCaseDirectory);

    const testResults = new Array<TestResult>();
    for(const testCase of testCases) {
        const testResult = await test(solutionExecutor, testCase)
        testResults.push(testResult);
    }

    const numberOfSuccess = testResults.filter(t => t.success).length
    console.log(`${numberOfSuccess} of ${testCases.length} OK!!\n`);
})();

