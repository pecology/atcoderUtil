import * as fs from "fs"

const STD_INPUT_FILEDESCRIPTOR = 0;
fs.readFile(STD_INPUT_FILEDESCRIPTOR, {encoding: "utf8"}, (err, stdInput) => {
    main(stdInput);
});

const main = (stdInput: string) => {
    // Write your code!!

    // process.stdout.write() does not insert a line break at the end
    // If you want, please use console.log()
};
