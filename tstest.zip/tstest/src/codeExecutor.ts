import Output from "./output";

export default interface CodeExecutor {
    execute: (standartInput?: string, ...commandLineArgs: string[]) => Promise<Output>,
}