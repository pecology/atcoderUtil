export default interface Output{
    exitCode: number | null,
    standardOutput: string | null,
    standardError: string | null
}