import { Writable, Stream, WritableOptions } from "stream";
import { Color } from "./Color";


export default class Logger{
    private indentDepth: number;
    private destStream: Writable;

    constructor(indentDepth: number = 0, destStream: Writable = process.stdout) {
        this.indentDepth = indentDepth;
        this.destStream = destStream;
    }

    public indent(depth: number) {
        this.indentDepth += depth;
    }

    public unindent(depth: number) {
        this.indentDepth -= depth;
        if(this.indentDepth < 0) {
            this.indentDepth = 0;
        }
    }

    public resetIndent() {
        this.indentDepth = 0;
    }

    public log(content: string, color: Color = Color.NONE) {
        const indentStr = '   '.repeat(this.indentDepth);

        const colorControlChar = "\u001b[" + color + "m";
        const colorControlResetChar = "\u001b[0m"
        const indentedContent = colorControlChar +
                                content.replace(/^/, indentStr)
                                       .replace(/\n/g, '\n' + indentStr) +
                                colorControlResetChar;
        this.destStream.write(indentedContent);
        this.destStream.write('\n');
    }
}