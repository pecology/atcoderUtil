import * as childProcess from "child_process"
import getPort from "get-port"
import { readAll } from "./util";
import Output from "./output";
import { resolve } from "url";

const isDebugMode = (): boolean => {
    return process.execArgv.some(arg => /--inspect-brk/.test(arg));
}

export default function execSolution(jsSrcPath: string, stdIn?: string, ...cmdArgs: string[]): Promise<Output> {
    //TODO refactoring
    return new Promise((resolve, reject) => {
        const childProcessExecArgv: string[] = new Array<string>();
        // if(isDebugMode()) {
        //     const portNo = await getPort();
        //     childProcessExecArgv.push(`--inspect-brk=${portNo}`);
        // }
        
        var child = childProcess.fork(jsSrcPath, [], 
        {
            execArgv: childProcessExecArgv,
            silent : true
        });

        child.stdin.write(stdIn);
        child.stdin.end();

        child.on("exit", async (code) => {
            try{
                resolve({
                    exitCode: code,
                    standardOutput: child.stdout.readableLength ? await readAll(child.stdout) : null,
                    standardError: child.stderr.readableLength ? await readAll(child.stderr) : null
                });
            } catch (e) {
                reject(e);
            }
        });
    });
}